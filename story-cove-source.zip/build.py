import json, re, glob, os, sys

base = os.path.dirname(os.path.abspath(__file__))
stories = []
problems = []
for path in sorted(glob.glob(os.path.join(base, 'stories', '*.txt'))):
    raw = open(path, encoding='utf-8').read()
    head, body = raw.split('\n###\n', 1)
    meta = {'vocab': [], 'quiz': []}
    for line in head.split('\n'):
        line = line.strip()
        if not line:
            continue
        key, _, val = line.partition(': ')
        if key == 'TITLE': meta['title'] = val
        elif key == 'CAT': meta['cat'] = val
        elif key == 'BLURB': meta['blurb'] = val
        elif key == 'VOCAB':
            for item in val.split(' ;; '):
                w, d = item.split(' | ', 1)
                meta['vocab'].append({'w': w.strip(), 'd': d.strip()})
        elif key == 'Q':
            parts = [p.strip() for p in val.split(' | ')]
            if len(parts) != 8:
                problems.append(f'{path}: quiz line has {len(parts)} parts: {val[:50]}')
                continue
            skill, q, a, b, c, d, idx, why = parts
            meta['quiz'].append({'skill': skill, 'q': q, 'opts': [a, b, c, d], 'ans': int(idx), 'why': why})
    meta['paras'] = [p.strip() for p in body.strip().split('\n\n') if p.strip()]
    text = ' '.join(meta['paras']).lower()
    for v in meta['vocab']:
        w = v['w'].lower()
        stem = w[:-1] if len(w) >= 7 and w.endswith('e') else w
        n = len(re.findall(r'\b' + re.escape(stem) + r'\w*', text))
        if n == 0:
            problems.append(f'{os.path.basename(path)}: vocab "{w}" not found in story')
    if len(meta['quiz']) != 5: problems.append(f'{path}: {len(meta["quiz"])} quiz items')
    if len(meta['vocab']) != 5: problems.append(f'{path}: {len(meta["vocab"])} vocab')
    stories.append(meta)

data = json.dumps(stories, ensure_ascii=False).replace('</', '<\\/')
tpl = open(os.path.join(base, 'template.html'), encoding='utf-8').read()
frag = tpl.replace('__DATA__', data)
os.makedirs('/mnt/user-data/outputs', exist_ok=True)
open(os.path.join(base, 'fragment.html'), 'w', encoding='utf-8').write(frag)
standalone = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
              '<meta name="viewport" content="width=device-width,initial-scale=1"></head><body>' + frag + '</body></html>')
open('/mnt/user-data/outputs/index.html', 'w', encoding='utf-8').write(standalone)
print(len(stories), 'stories;', len(frag)//1024, 'KB')
print('\n'.join(problems) or 'no problems')
